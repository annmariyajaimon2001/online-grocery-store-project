package com.example.GrocoOnlineGroceryStore.service;

import com.example.GrocoOnlineGroceryStore.entity.Purchase;
import com.example.GrocoOnlineGroceryStore.repository.PurchaseItemRepository;
import com.example.GrocoOnlineGroceryStore.repository.PurchaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PurchaseService {

    @Autowired
    private PurchaseRepository purchaseRepository;

    @Autowired
    private PurchaseItemRepository purchaseItemRepository;

    public void savePurchase(Purchase purchase) {
        purchaseRepository.save(purchase);
    }

    public List<Purchase> getAllPurchases() {
        return purchaseRepository.findAll();
    }
}

