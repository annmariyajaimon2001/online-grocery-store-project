package com.example.GrocoOnlineGroceryStore.entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Cart {
    private Map<Long, CartItem> items;

    public Cart() {
        this.items = new HashMap<>(); // Initialize the items map
    }

    public Map<Long, CartItem> getItems() {
        return items;
    }

    public void setItems(Map<Long, CartItem> items) {
        this.items = items;
    }

    // Convert the map values to a list
    public List<CartItem> getItemList() {
        return items.values().stream().collect(Collectors.toList());
    }

    public void addItem(Product product, int quantity) {
        CartItem item = items.get(product.getId());
        if (item == null) {
            item = new CartItem(product, quantity);
            items.put(product.getId(), item);
        } else {
            item.setQuantity(item.getQuantity() + quantity);
        }
    }

    public void updateItemQuantity(Long productId, int quantity) {
        CartItem item = items.get(productId);
        if (item != null) {
            item.setQuantity(quantity);
        }
    }

    public void removeItem(Long productId) {
        items.remove(productId);
    }

    public int getItemQuantity(Long productId) {
        CartItem item = items.get(productId);
        return (item != null) ? item.getQuantity() : 0;
    }



    public double getTotalPrice() {
        double totalPrice = 0.0;
        for (CartItem item : items.values()) {
            totalPrice += item.getProduct().getPrice() * item.getQuantity();
        }
        return totalPrice;
    }
}

