package com.example.GrocoOnlineGroceryStore.repository;

import com.example.GrocoOnlineGroceryStore.entity.PurchaseItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PurchaseItemRepository extends JpaRepository<PurchaseItem, Long> {
}
