package com.example.GrocoOnlineGroceryStore.controller;

import com.example.GrocoOnlineGroceryStore.entity.*;
import com.example.GrocoOnlineGroceryStore.service.PurchaseService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Controller
public class PaymentController {
    @Autowired
    private PurchaseService purchaseService;

    @GetMapping("/payment")
    public String showPaymentPage(Model model) {
        return "payment";
    }

    @PostMapping("/payment/submit")
    public String submitPayment(String deliveryAddress, String paymentMethod, Model model, HttpSession session) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        Cart cart = (Cart) session.getAttribute("cart");

        if (loggedInUser == null || cart == null || cart.getItems().isEmpty()) {
            return "redirect:/error";
        }

        Purchase purchase = new Purchase();
        purchase.setUser(loggedInUser);
        purchase.setDeliveryAddress(deliveryAddress);
        purchase.setPaymentMethod(paymentMethod);
        purchase.setPurchaseDate(LocalDateTime.now());

        List<PurchaseItem> purchaseItems = new ArrayList<>();
        for (CartItem cartItem : cart.getItemList()) {
            PurchaseItem purchaseItem = new PurchaseItem();
            purchaseItem.setPurchase(purchase);
            purchaseItem.setProduct(cartItem.getProduct());
            purchaseItem.setQuantity(cartItem.getQuantity());
            purchaseItem.setPrice(cartItem.getProduct().getPrice());
            purchaseItems.add(purchaseItem);
        }

        purchase.setItems(purchaseItems);
        purchaseService.savePurchase(purchase);

        session.setAttribute("paymentSuccess", true);
        model.addAttribute("deliveryAddress", deliveryAddress);
        model.addAttribute("paymentMethod", paymentMethod);
        session.removeAttribute("cart");

        return "paymentSuccess";
    }

    @GetMapping("/payment/success")
    public String showPaymentSuccessPage(Model model, HttpSession session) {
        // Check if payment was successful
        Boolean paymentSuccess = (Boolean) session.getAttribute("paymentSuccess");

        if (paymentSuccess == null || !paymentSuccess) {
            // Redirect to some error page or handle the case where payment wasn't successful
            return "redirect:/error";
        }



        // Retrieve details from session and pass to the view
        String deliveryAddress = (String) session.getAttribute("deliveryAddress");
        String paymentMethod = (String) session.getAttribute("paymentMethod");

        model.addAttribute("deliveryAddress", deliveryAddress);
        model.addAttribute("paymentMethod", paymentMethod);

        // Clear session attributes related to payment
        session.removeAttribute("deliveryAddress");
        session.removeAttribute("paymentMethod");
        session.removeAttribute("paymentSuccess");

        return "paymentSuccess";
    }
}
